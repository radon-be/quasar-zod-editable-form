import type { IndexAPI } from '@quasar/app-vite'

export default function (api: IndexAPI) {
  api.extendQuasarConf((conf) => {
    conf.boot?.push('~@radon-be/quasar-app-extension-zod-form/src/boot/register')
  })
}

export { default as ZodForm } from './components/ZodForm.vue'
export { provideZodFormI18n, createZodFormI18nPlugin, useZodFormI18n } from './composables/useZodFormI18n'
export type {
  I18nLabels,
  PropertyKeyType,
  PropertyEditType,
  PropertyEditControlType,
  ExtraPropertyOptions,
  ExtraPropertyOptionsBase,
  ExtraPropertyOptionSelectLike,
} from './types/form.type'
